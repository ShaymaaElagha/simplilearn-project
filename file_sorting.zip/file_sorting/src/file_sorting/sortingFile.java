package file_sorting;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class sortingFile {

	public void listFilesInAscendingOrder() throws IOException {
		// String fileLocation=
		// System.getProperty("user.dir");
		String FILE_PATH = System.getProperty("user.dir");
		File directoryPath = new File(FILE_PATH + "\\src\\file_sorting\\files");

		String[] contents = directoryPath.list();
		File[] file_list = directoryPath.listFiles();
		String[] fileNames=new String[contents.length];
		
		System.out.println(contents.length);
		System.out.println("List of files and directories in ascending order");
		for (int i = 0; i < contents.length; i++) {
			System.out.println(contents[i]);
			fileNames[i]=file_list[i].getName();
			
		}
		Arrays.sort(fileNames);
		System.out.println(Arrays.toString(fileNames));
	}

}
