package file_sorting;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class fileHandling {

	String FILE_PATH = System.getProperty("user.dir");
	File directoryPath = new File(FILE_PATH + "\\src\\file_sorting\\files");
	String[] contents = directoryPath.list();
	File[] file_list = directoryPath.listFiles();
	Scanner reader = new Scanner(System.in);

	public void addFile() {

		boolean success = false;
		System.out.println("Enter file name to be created");
		String filename = reader.nextLine();
		File f = new File(FILE_PATH + "\\src\\file_sorting\\files\\" + filename);
		if (f.exists()) {
			System.out.println("File already exists");
		} else {
			System.out.println("No such file exists, creating now");
			try {
				success = f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (success) {
				System.out.printf("Successfully created new file: %s%n", f);
			} else {
				System.out.printf("Failed to create new file: %s%n", f);
			}
		} // close Scanner to prevent resource leak reader.close();
	}

	public void deleteFile() {

		System.out.println("Enter file name to be deleted");
		String filename = reader.nextLine();
		File f = new File(FILE_PATH + "\\src\\file_sorting\\files\\" + filename);

		// String fileNames[]={};
		System.out.println(contents.length);
		int deleted = 0;

		for (int i = 0; i < contents.length; i++) {
			// System.out.println(contents[i]);
			// file_list[i].getName();
			if (filename.equals(file_list[i].getName())) {
				f.delete();
				System.out.printf("Successfully deleted");
				deleted = 1;
			}
			;

		}

		if (deleted == 0) {
			System.out.printf(filename + " is not exist");
		}

	}

	public void fileSearch() {
		System.out.println("Enter file name you search for");
		String filename = reader.nextLine();
		File f = new File(FILE_PATH + "\\src\\file_sorting\\files\\" + filename);
		int found = 0;
		for (int i = 0; i < contents.length; i++) {
			// System.out.println(contents[i]);
			// file_list[i].getName();

			if (filename.equals(file_list[i].getName())) {

				System.out.printf(filename + " is found");
				found = 1;

			}
			;

		}
		if (found == 0) {
			System.out.printf(filename + " is not found");
		}

	}
}
