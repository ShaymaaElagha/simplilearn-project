package file_sorting;

import java.io.IOException;
import java.util.Scanner;

public class sortingFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		fileHandling file_handling = new fileHandling();
		System.out.println("welecome to handling files project developed by Shaymaa");
		System.out.println("Enter one of the following commands:");
		System.out.println("1 - option one to present file in ascending order");
		System.out.println("2 - option two to add ,delete and search for file ");
		System.out.println("3 - exit");
		Scanner scanchoice = new Scanner(System.in);
		System.out.println();
		int choiceentry =-1;

		while (choiceentry < 1 || choiceentry > 3) {

			System.out.println("Enter \"1\", \"2\" or \"3\"");
			if (scanchoice.hasNextInt())
				choiceentry = scanchoice.nextInt();

		}

		switch (choiceentry) {
		case 1:
			sortingFile listFile = new sortingFile();

			try {
				listFile.listFilesInAscendingOrder();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case 2:
			System.out.println("Enter one of the following commands:");
			System.out.println("1 - add file");
			System.out.println("2 - delete file ");
			System.out.println("3 - search file");
			System.out.println("4 - go back to main menu");
			int choiceentry1 = -1;

			while (choiceentry1 < 1 || choiceentry1 > 4) {

				System.out.println("Enter \"1\", \"2\", \"3\" or \"4\"");
				if (scanchoice.hasNextInt())
					choiceentry1 = scanchoice.nextInt();

			}
			switch (choiceentry1) {
			case 1:
				// add file
				file_handling.addFile();
				break;
			case 2:
				// delete file
				file_handling.deleteFile();
				break;
			case 3:
				// search file
				file_handling.fileSearch();
				break;
			case 4:
				sortingFiles.main(args);
				break;
			}

			break;
		case 3:

			break;
		}
	}

}
